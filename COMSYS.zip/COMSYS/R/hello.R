#'@import lmtest
#'@import rSymPy
#install.packages("lmtest")
#library(lmtest)
#install.packages("rSymPy")
#library(rSymPy)

#' @title FilterAmp
#' @description Using the statistical method AVT, amplitude noise is removed from a signal. This method works including points from the mean to 1.5 standard deviations upward and downward.
#' @param datos coordinates of data points from the signal
#'
#' @return filtered data, signal with noise removed
#' @export FilterAmp
#'

FilterAmp=function(datos){
  prom=mean(datos)
  stddev=0
  for(i in c(1:length(datos))){
    stddev=stddev+(datos[i]-prom)^2
  }
  stddev=sqrt((1/length(datos))*stddev)
  datosfin=c()
  cont=1
  for(i in c(1:length(datos))){
    if(datos[i]<=prom+1.5*stddev && datos[i]>=prom-1.5*stddev){
      datosfin[cont]=datos[i]
      cont=cont+1
    }
  }
  return(datosfin)
}
#' @title  FilterReg
#' @description Using LOESS and LOWESS methods, filtering is performed allowing it to have a clean signal. This methods work as local regressions. Afterwards it calculates the error respect to the original signal if the entry is 2*sin(t).
#' @param t time coordinates of the signal
#' @param datos signal data (Should be the same size as the t vector)
#' @param frac Defines the amount of data used in each fraction analysis for LOESS and LOWESS methods, should be a number higher or equal to 0.078 and lower or equal to 1
#' @param tipo Filter type, 1 is for LOESS and 2 for LOWESS any other value will result in NULL. The LOESS filter works better with linear functions, whilst LOWESS works better with curves.
#'
#' @return A list containing in "datos" the filtered data and containing in "error" the error of the filtered signal respect to the original signal. (This error only works with the example entry 2*sin(t))
#' @export FilerReg
#'

FilterReg=function(t,datos,frac,tipo){
  if(tipo==1){
    reg=loess(datos~t,span=frac)
    datosfin=predict(reg)
    error=abs(datosfin-2*sin(t))/abs(2*sin(t))
    errormat=matrix(c(t,error),nrow=length(t),ncol=2,dimnames=list(1:length(t),c("t","error")))
    res=list()
    res$datos=datosfin
    res$error=errormat
    return(res)
  }else if(tipo==2){
    reg=lowess(datos~t,f=frac)
    error=(reg$y-2*sin(t))/abs(2*sin(t))
    errormat=matrix(c(t,error),nrow=length(t),ncol=2,dimnames=list(1:length(t),c("t","error")))
    res=list()
    res$datos=reg$y
    res$error=errormat
    return(res)
  }else{
    return(NULL)
  }
}

#' @title FuncId
#' @description using regression methods, it returns the best fitting function for the data given
#'
#' @param t time coordinates of the signal
#' @param datos signal data (Should be the same size of the t vector)
#'
#' @return A vector containing in its first position the best fit type and in its second position the correlation given with the fit type. Fit type 1 is a linear function, type 2 a sine function, type 3 a cosine function, type 4 a tangent function, type 5 an exponential function, type 6 a logarithmic function, type 7 a rational function, type 8 a cuadratic function, type 9 a third order polynomial and type 10 a linear combination of sines and cosines.
#' @export FuncId
#'

FuncId=function(t,datos){
  corrAct=0
  tipAct=0
  m=lm(datos~t)
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=1
  }
  m=lm(datos~sin(t))
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=2
  }
  m=lm(datos~cos(t))
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=3
  }
  m=lm(datos~tan(t))
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=4
  }
  m=lm(datos~exp(t))
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=5
  }
  if(min(t)>0){
    m=lm(datos~log(t))
    if(corrAct<summary(m)$r.squared){
      corrAct=summary(m)$r.squared
      tipAct=6
    }
  }
  if(min(t)>0){
    m=lm(datos~I(1/t))
    if(corrAct<summary(m)$r.squared){
      corrAct=summary(m)$r.squared
      tipAct=7
    }
  }
  m=lm(datos~I(t^2)+t)
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=8
  }
  m=lm(datos~I(t^3)+I(t^2)+t)
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=9
  }
  m=lm(datos~cos(t)+sin(t))
  if(corrAct<summary(m)$r.squared){
    corrAct=summary(m)$r.squared
    tipAct=10
  }
  return(c(tipAct,corrAct))
}

#' @title Recons
#' @description This function receives the type of function given by FuncId and reconstructs the original function using the model provided in type.
#'
#' @param t time coordinates of the signal
#' @param datos Signal data (Should be the same size as the t vector)
#' @param tipo Type of the function returned in FuncId, types for Recons are in the same order. Fit type 1 is a linear function, type 2 a sine function, type 3 a cosine function, type 4 a tangent function, type 5 an exponential function, type 6 a logarithmic function, type 7 a rational function, type 8 a cuadratic function, type 9 a third order polynomial and type 10 a linear combination of sines and cosines. Otherwise it will return NULL.
#'
#' @return The resulting function after finishing regression
#' @export
#'

Recons=function(t,datos,tipo){
  if(tipo==1){
    m=lm(datos~t)
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*t
    }
    return(f)
  }
  if(tipo==2){
    m=lm(datos~sin(t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*sin(t)
    }
    return(f)
  }
  if(tipo==3){
    m=lm(datos~cos(t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*cos(t)
    }
    return(f)
  }
  if(tipo==4){
    m=lm(datos~tan(t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*tan(t)
    }
    return(f)
  }
  if(tipo==5){
    m=lm(datos~exp(t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*exp(t)
    }
    return(f)
  }
  if(tipo==6){
    m=lm(datos~log(t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*log(t)
    }
    return(f)
  }
  if(tipo==7){
    m=lm(datos~I(1/t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*1/t
    }
    return(f)
  }
  if(tipo==8){
    m=lm(datos~I(t^2)+t)
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*t^2+m$coefficients[3]*t
    }
    return(f)
  }
  if(tipo==9){
    m=lm(datos~I(t^3)+I(t^2)+t)
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*t^3+m$coefficients[3]*t^2+m$coefficients[4]*t
    }
    return(f)
  }
  if(tipo==10){
    m=lm(datos~cos(t)+sin(t))
    f=function(t){
      m$coefficients[1]+m$coefficients[2]*cos(t)+m$coefficients[3]*sin(t)
    }
    return(f)
  }
  return(NULL)
}













